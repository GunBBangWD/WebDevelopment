<html>
	<head>
	<title>Bulb</title>
	<link rel="stylesheet" href="bulb.css">
	</head>
	
	<body>
		<div class="toggle">
			<input type="checkbox">
		</div>
	
	</body>
</html>