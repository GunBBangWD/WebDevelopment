package org.example;

public class Main {
    public static void main(String[] args) {

        Person hong = new Person("hong", 33);
        Person Kim = new Person("Kim", 44);

        Building samsung_Tower = new Building("samsung_Tower","GangNam");
        Building hyndae_Tower = new Building("hyndae_Tower", "GangNam");

        samsung_Tower.addResident(hong);
        hyndae_Tower.addResident(Kim);
        samsung_Tower.printBuildingInfo();
        hyndae_Tower.printBuildingInfo();
        City city = new City("Seoul");
        city.addBuilding(samsung_Tower);
        city.addBuilding(hyndae_Tower);
        city.printCityInfo();
    }
}