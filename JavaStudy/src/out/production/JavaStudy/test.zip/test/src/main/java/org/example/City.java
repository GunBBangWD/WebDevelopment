package org.example;

import java.util.ArrayList;

public class City {
    private String cityName;
    private ArrayList<Building> bulidings;
    City(String cityName){
        bulidings = new ArrayList<>();
        this.cityName = cityName;
    }
    ArrayList<Building> addBuilding(Building building){
        bulidings.add(building);
        return bulidings;
    }



    void printCityInfo(){
        for(Building building : bulidings){
            System.out.println("cityname : "+cityName);
            System.out.println("building " +building);
            System.out.println("getBuildingName : " + building.getBuildingName());
            System.out.println("getAddress :"+ building.getAddress());
            System.out.println("getResidents : "+building.getResidents());
        }
    }
}
