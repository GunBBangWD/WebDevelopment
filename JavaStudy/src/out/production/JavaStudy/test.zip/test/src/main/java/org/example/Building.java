package org.example;

import java.util.ArrayList;

public class Building {
    private String buildingName;
    private String address;
    private ArrayList<Person> residents;
    Building(String buildingName,String address){
        residents = new ArrayList<>();
        this.buildingName =buildingName;
        this.address = address;
    }
    void printBuildingInfo(){
        System.out.println("bulidingName:" + buildingName);
        System.out.println("buildingAddress:"+address);
        for(Person person : residents){
            System.out.println(person);
        }
    }
    ArrayList<Person> addResident(Person person) {
        residents.add(person);
        return residents;
    }

    public ArrayList<Person> getResidents() {
        return residents;
    }


    public String getBuildingName() {
        return buildingName;
    }

    public void setBuildingName(String buildingName) {
        this.buildingName = buildingName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public String toString() {
        return "Building{" +
                "buildingName='" + buildingName + '\'' +
                ", address='" + address + '\'' +
                ", residents=" + residents +
                '}';
    }
}
